package com.travel.travel.repository;
import java.util.*;import org.springframework.data.jpa.repository.*;import org.springframework.data.repository.query.Param;
import jakarta.persistence.LockModeType;import com.travel.travel.entity.Travel;
public interface TravelRepository extends JpaRepository<Travel,Long>{
@Lock(LockModeType.PESSIMISTIC_WRITE) @Query("select t from Travel t where t.id=:id") Optional<Travel> lockById(@Param("id") Long id);
}
