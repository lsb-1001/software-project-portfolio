package com.travel.travel.repository;
import org.springframework.data.jpa.repository.JpaRepository;import com.travel.travel.entity.Member;
public interface MemberRepository extends JpaRepository<Member,Long>{Member findByUsername(String username);}
